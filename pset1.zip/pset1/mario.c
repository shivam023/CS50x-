#include <stdio.h>
#include <cs50.h>
int main(void){
    int h;
    
    do{
        printf("Height: ");
        h = GetInt();
    }
    while(h<0 || h>23);
    
    for(int i=0; i<h; i++){
        for(int j=0; j<h-i-1; j++){
            printf(" ");
        }
        
        for(int j=h-i-1; j<h+1; j++){
            printf("#");
        }
        printf("\n");
    }
}