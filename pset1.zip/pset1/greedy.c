#include <stdio.h>
#include <cs50.h>
#include <math.h>
int main(void){
    int coins = 0, temp;
    float owed;
    do{
        printf("How much change is owed?\n");
        owed = GetFloat();
    }
    while(owed<=0);
    
    temp = round(owed*100);
    
    while(temp>0){
        if(temp>=25){
            temp -= 25;
            coins++;
        }
        else if(temp>=10){
            temp -= 10;
            coins++;
        }
        else if(temp>=5){
            temp -= 5;
            coins++;
        }
        else if(temp>=1){
            temp -= 1;
            coins++;
        }
    }
    printf("%d\n",coins);
}