<table class="table table-striped">
    <thead>
        <tr>
            <th>Symbol</th>
            <th>Name</th> 
            <th>Shares</th>
            <th>Price</th>
            <th>TOTAL</th>
       </tr>
    </thead>
    <tbody>
        <?php foreach ($positions as $position): ?>

            <tr>
            <td style="text-align: left;"><?= $position["symbol"] ?></td>
            <td style="text-align: left;"><?= $position["name"] ?></td>
            <td style="text-align: left;"><?= $position["shares"] ?></td>
            <td style="text-align: left;">$<?= number_format($position["price"], 2) ?></td>
            <td style="text-align: left;">$<?= number_format($position["shares"] * $position["price"], 2) ?></td>
        </tr>

        
        <?php endforeach ?>
       <tr>
            <td style="text-align: left;">CASH</td>
            <td></td>
            <td></td>
            <td></td>
            <td style="text-align: left;">$<?= number_format($cash, 2) ?></td>
        </tr>
    </tbody>
</table>