<table class="table table-striped">
    <thead>
        <tr>
            <th>Transaction</th>
            <th>Date/Time</th> 
            <th>Symbol</th>
            <th>Shares</th>
            <th>Price</th>
       </tr>
    </thead>
    <tbody>
<?php foreach ($history as $transactions): ?>
    
        <tr>
            <td style="text-align:left"><?= $transactions["transaction"] ?></td>
            <td style="text-align:left"><?= $transactions["time"] ?></td>
            <td style="text-align:left"><?= $transactions["symbol"] ?></td>
            <td style="text-align:left"><?= $transactions["shares"] ?></td>
            <td style="text-align:left">$<?= number_format($transactions["price"], 2) ?></td>
        </tr>
<?php endforeach ?>
    </tbody>
</table>
