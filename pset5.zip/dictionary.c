/****************************************************************************
 * dictionary.c
 *
 * Computer Science 50
 * Problem Set 6
 *
 * Implements a dictionary's functionality.
 ***************************************************************************/

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>

#include "dictionary.h"

// typedef a node for the linked lists
typedef struct node
{
    char word[LENGTH + 1];
    struct node* next;
}
node;

//hash table with size same as number of words
int HASH_SIZE = 143091;
int lines = 0;

node* hashtable[143091];

unsigned long hash(char *str)
{
    unsigned long hash = 5381;
    int c;
    
    while ((c = *str++))
    hash = ((hash << 5) + hash) + c; /* hash * 33 + c */

    return hash  % HASH_SIZE;
}
/**
 * Returns true if word is in dictionary else false.
 */
bool check(const char* word)
{
    int len = strlen(word);
    // store word with converted letters to lowercase 
    char* lower_word = malloc(sizeof(char)*(len+1));
    if (lower_word == NULL)
    {
        printf("Out of memory\n");
        return false;
    }
    
    // convert letter to lowercase
    for (int i = 0; i < len; i++)
    {  
        lower_word[i] = tolower(word[i]);
    }
    lower_word[len] = '\0';
    
    // hash that word
    long key = hash(lower_word);   
    node* new = hashtable[key];
    
    // check if word is in dictionary
    while (new != NULL)
    { 
        if (strcmp (new->word, lower_word) == 0)
        {
            free(lower_word);
            return true;
        }
        else
        {
            new = new->next;
        }
    }
    free(lower_word);
    return false;
}

/**
 * Loads dictionary into memory.  Returns true if successful else false.
 */
bool load(const char* dictionary)
{
    // open dictionary
    FILE* dic = fopen(dictionary, "r");
    if (dic == NULL)
    {
        printf("Could not open %s.\n", dictionary);
        return 1;
    }
    
    while (true)
    {
        // malloc a *node for each new word
        node* new_node = malloc(sizeof(node));
        
        if (new_node == NULL)
        {
            printf("Out of memory\n");
            return false;
        } 
    
        // scan a string from our dictionary file into new_node->word (destionation of that word)
        fscanf(dic, "%s", new_node->word);
    
        if(feof(dic))
        {
            free(new_node);
            break;
        }
        
        // hash that word
        long key = hash(new_node->word);
    
        // add new node to head of list
        new_node->next = hashtable[key];
        hashtable[key] = new_node;
        lines++;
       
    }
    
    // close dictionary
    fclose(dic);
      
    return true;
}

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
    
    return lines;
}

/**
 * Unloads dictionary from memory.  Returns true if successful else false.
 */
bool unload(void)
{
    for (int i = 0; i < HASH_SIZE; i++)
    {
        node* curr = hashtable[i];
        node* prev = NULL;    
    
        while (curr != NULL)
        {
            prev = curr;
            curr = curr->next;
            free(prev);
        }
    }
    return true;
}

