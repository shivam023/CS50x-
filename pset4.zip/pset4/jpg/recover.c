/**
 * recover.c
 *
 * Computer Science 50
 * Problem Set 4
 *
 * Recovers JPEGs from a forensic image.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

int main(void)
{
		// Open the cardfile, return if there's a problem with it
		FILE* fp = fopen("card.raw", "r");	

		if(fp == NULL)
		{	
				fclose(fp);
				fprintf(stderr, "Wasn't able to open the cardfile.\n");
				return 1;
		}

		// This keeps track of jpeg files found in the bytestream
		// We use it to create filenames.
		int jpgcount = 0;

		// Open outfile indicator
		int open = 0;
		FILE* outp;

	  // Read 512b blocks from file.
		uint8_t buffer[512];
		uint8_t check[4];
		fread(buffer, 512, 1, fp);	

		while(fread(buffer, 512, 1, fp) > 0)
		{
				// get first 4 bytes
				for(int i = 0; i < 4; i++)
				{
						check[i] = buffer[i];
				}

				// Check if it is jpeg
				if(check[0] == 0xff && check[1] == 0xd8 && check[2] == 0xff && (check[3] == 0xe0 || check[3] == 0xe1))
				{
						// Construct the filename
						char filename[8];
						sprintf(filename, "%03d.jpg", jpgcount);
						
						//first jpg
						if(open == 0)
						{
								outp = fopen(filename, "w");
								fwrite(buffer, sizeof(buffer), 1, outp);
								open = 1;
						}
						//new jpg starts end previous
						if(open == 1)
						{
								fclose(outp);
								outp = fopen(filename, "w");
								fwrite(buffer, sizeof(buffer), 1, outp);
								jpgcount++;
						}
				}
				//continue writing
				else
				{
						if(open == 1)
						{
								fwrite(buffer, sizeof(buffer), 1, outp);
						}
				}
		}
    
		
    if(outp)
    {
      fclose(outp);
    }

		fclose(fp);
		return 0;
}