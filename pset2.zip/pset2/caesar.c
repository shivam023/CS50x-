#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cs50.h>

int main(int argc, string argv[]){
    string s;
    if(argc != 2){
        printf("Not enough command line arguments\n"); // for checking the number of command line arguments
        return 1;
    }

    int k = atoi(argv[1]);
    k = k % 26;
    if(k < 0){
        printf("Must be positive\n");
        return 1;
    }

    s = GetString();
    char p;
    int c;
    for(int i = 0, len = strlen(s); i < len; i++)
    {
        p = s[i];

        c = p + k;

        if((p >= 65 && p <= 90 && c > 90) || (p >= 97 && p <= 122 && c > 122))
        {
            c = p - (26 - k);
        	printf("%c", c);
        }
        else if ((p >= 65 && p <= 90) || (p >= 97 && p <= 122))
        {
        	printf("%c", c);
        }
        else
        {
        	printf("%c", p);
        }

    }

	printf("\n");

    return 0;
}
