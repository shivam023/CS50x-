#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main(int argc, string argv[])
{
    char p;
    int c;
    int temp;
    if(argc != 2)
    {
        printf("Not enough command line arguments\n");// for checking number of command line arguments
        return 1;
    }

    string s = argv[1];
    int klen = strlen(s);
    int k[klen];
    int ki;

    for(int i = 0; i < klen; i++){
        ki = s[i];
        if(ki >= 65 && ki <= 90){
            k[i] = ki - 65;
        }
        else if(ki >= 97 && ki <= 122){
            k[i] = ki - 97;
        }
        else {
            printf("Non-alpha characters found\n");
            return 1;
        }
    }

    string x;
    do{
        x = GetString();
    }
    while (strlen(x) == 0);
    ki = 0;
    for(int i = 0, len = strlen(x); i < len; i++){
        p = x[i];
        if (p >= 65 && p <= 90) {
            temp = 65;
        }
        else if (p >= 97 && p <= 122){
        	temp = 97;
        }
        else{
            temp = 0;
        }

        if(temp > 0){
            c = (((p - temp) + k[ki]) % 26) + temp;
            ki = (ki + 1) % klen;
        }
        else{
            c = p;
        }
        printf("%c", c);
    }

    printf("\n");


    return 0;
}
