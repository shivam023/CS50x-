#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <cs50.h>

int main(void){
    string s;
    s=GetString();
    printf("%c",toupper(s[0]));
    for(int i=1;i<strlen(s);i++){
        if(s[i-1]==' '){
            printf("%c",toupper(s[i]));
        }
    }
    printf("\n");
}